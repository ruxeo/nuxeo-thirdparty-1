#ifndef PREVIEW_H
#define PREVIEW_H

#include "ccextractorGUI.h"

int preview(struct nk_context *ctx, int x, int y, int width, int height, struct main_tab *main_settings);

#endif //!PREVIEW_H
