#ifndef ACTIVITY_H
#define ACTIVITY_H

#include "ccextractorGUI.h"

int activity(struct nk_context *ctx, int x, int y, int width, int height, struct main_tab *main_settings);

#endif
