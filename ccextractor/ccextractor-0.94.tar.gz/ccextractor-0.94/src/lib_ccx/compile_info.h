#ifndef CCX_CCEXTRACTOR_COMPILE_H
#define CCX_CCEXTRACTOR_COMPILE_H
#ifndef VERSION_FILE_PRESENT
#define GIT_COMMIT "Unknown"
#define COMPILE_DATE "Unknown"
#else
#include "compile_info_real.h"
#endif
#endif