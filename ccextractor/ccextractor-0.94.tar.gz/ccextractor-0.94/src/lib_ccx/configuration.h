#ifndef _CONFIGURATION_H
#define _CONFIGURATION_H
void parse_configuration(struct ccx_s_options *opt);
#endif
