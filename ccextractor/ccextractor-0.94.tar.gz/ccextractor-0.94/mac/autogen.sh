#!/bin/bash

./pre-build.sh
autoreconf -i
