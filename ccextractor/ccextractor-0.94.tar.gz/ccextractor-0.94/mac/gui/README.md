## Simple MacOS GUI for CCExtractor
This is a simple GUI for MacOS. It was generated using the open source Platypus tool created by [Sveinbjörn Þórðarson](https://sveinbjorn.org). You can learn more about Platypus [here.](https://sveinbjorn.org/platypus) It is recommended if you need more customization please use the CLI tool as this app only has the default settings.
