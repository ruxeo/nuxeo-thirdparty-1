# HowToGenerateApp

## Main App

Script Type: Shell

Script Path: script.sh located in src folder

Interface: Droplet

Remain running after execution: Enabled

Accept Dropped Files: Enabled

## Install App

Script Type: Apple Script

Script Path: InstallCCExtractor.scpt located in src folder

Interface: Progress Bar

Bundled Files: CCExtractor.dmg located in src folder

Remain running after execution: Disabled
