#!/usr/bin/env bash

./pre-build.sh
autoreconf -i
